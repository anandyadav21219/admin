function getEndpoints() {
    return {

    // Production configuration
//    'client': 'admin-api.akedo.gg',
//    'asset': 'd1n2mqts4lqg92.cloudfront.net',

    // Dev configuration
     'client': 'dev-admin-api.akedo.gg',
     'asset': 'd161n2kbw2fw8g.cloudfront.net',

    };
}